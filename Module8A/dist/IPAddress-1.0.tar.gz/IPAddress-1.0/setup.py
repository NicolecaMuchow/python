from setuptools import setup

setup(
    name= "IPAddress",
    version = "1.0",
    desciption = "Scrape IP address from checkip.dyndns.org",
    author = "NM",
    author_email = "nmuchow@academic.rrc.ca",
    py_modules = ["ip_address"]
)
